exports.databaseErrorCode={
    "ER_BAD_NULL_ERROR":{message:"The input is wrong",status:422},
    "PROTOCOL_CONNECTION_LOST":{message:"Server error",status:500},
}