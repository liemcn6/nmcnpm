exports.defaultAvatarLink="/img/anomyous.png";
exports.defaultImgFolder="/roomImg/"
exports.concatSeparator="--";