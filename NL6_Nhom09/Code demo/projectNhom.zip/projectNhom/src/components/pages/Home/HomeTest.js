import React from 'react'

 const HomeTest=()=>{

    return (
        <div>Hello</div>
    )
}
export default HomeTest