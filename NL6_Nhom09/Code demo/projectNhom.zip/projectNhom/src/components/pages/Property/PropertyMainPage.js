import React from "react";


const PropertyMainPage=(props)=>{

    return (
        <div>List home here</div>
    )
}