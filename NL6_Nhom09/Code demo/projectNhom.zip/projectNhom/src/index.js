import React from "react";
import ReactDOM from "react-dom";
import {AppWithContexts} from "./AppWithContexts";
// import {Loading} from "@Components/shared/CNLoading/CNLoading"


ReactDOM.render(<AppWithContexts />,document.getElementById("root"));