export const userPermission={
    GUEST:-1,
    MEMBER:0,
    CO_ADMIN:1,
}

export const roomStatus={
    HIDDEN:-1,
    PENDING:0,
    SHOW:1
}