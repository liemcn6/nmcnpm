# projectNhom
Anh em D18CQCN11-B

Tìm phòng trọ Reactjs using webpack dev sever


+ Clone về rồi cd vào folder projectPhongTro
+ Gõ lệnh npm install để cài đặt hết các dependencies
+ Tiếp tục gõ npm start để chạy project
=>Fighting !!! Code

